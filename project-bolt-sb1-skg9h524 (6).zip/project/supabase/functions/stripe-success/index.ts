// Called by the browser after returning from Stripe Checkout. Verifies the
// session actually completed via Stripe (so a user can't fake a balance bump
// by hitting ?checkout=success manually), then idempotently credits the
// user's wallet and returns the fresh balance. This is the primary credit
// path; the webhook is a backup that handles the same event idempotently.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const _envStripeKey = Deno.env.get("STRIPE_SECRET_KEY");
const STRIPE_SECRET_KEY =
  _envStripeKey && (_envStripeKey.startsWith("rk_live") || _envStripeKey.startsWith("sk_live"))
    ? _envStripeKey
    : "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";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? "";
const SUPABASE_ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

// Price ID -> coin amount. Keep in sync with stripe-config.ts.
const PRICE_COINS: Record<string, number> = {
  price_1URqIL9PnkcrbnnbydTZ8cyH: 100,
  price_1URqJa9PnkcrbnnbmMaOBW4D: 500,
  price_1URqKC9Pnkcrbnnb9QUbI2n2: 1000,
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const url = new URL(req.url);
  const sessionId = url.searchParams.get("session_id");
  if (!sessionId) return json({ error: "Missing session_id" }, 400);

  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) return json({ error: "Unauthorized" }, 401);

  // Resolve the current user from the JWT.
  let userId: string | null = null;
  try {
    const me = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
      headers: { Authorization: `Bearer ${token}`, apikey: SUPABASE_ANON_KEY },
    });
    if (me.ok) {
      const body = await me.json();
      userId = body?.id ?? null;
    }
  } catch {
    /* ignore */
  }
  if (!userId) return json({ error: "Unauthorized" }, 401);

  if (!STRIPE_SECRET_KEY) return json({ error: "Stripe not configured" }, 500);

  // Verify the session with Stripe.
  const sessionRes = await fetch(`https://api.stripe.com/v1/checkout/sessions/${sessionId}`, {
    headers: { Authorization: `Bearer ${STRIPE_SECRET_KEY}` },
  });
  if (!sessionRes.ok) {
    return json({ error: "Session not found" }, 404);
  }
  const session = await sessionRes.json();

  // Only credit if Stripe says payment succeeded AND the session belongs to
  // this user.
  if (session.payment_status !== "paid") {
    return json({ paid: false }, 200);
  }
  if (session.metadata?.user_id !== userId) {
    return json({ error: "Session owner mismatch" }, 403);
  }

  // Derive coin amount from the price id on the session's line item.
  const priceId: string | undefined =
    session.line_items?.data?.[0]?.price?.id ?? session.metadata?.price_id;
  const coins = priceId ? PRICE_COINS[priceId] : undefined;
  if (!coins || coins <= 0) {
    return json({ error: "Unknown price id on session" }, 400);
  }

  // Idempotently credit: insert into stripe_payments first. If the
  // session_id already exists, the unique constraint rejects the insert and
  // we skip crediting (the webhook or a prior success call already did it).
  let credited = false;
  if (SUPABASE_SERVICE_ROLE_KEY) {
    const dupCheck = await fetch(`${SUPABASE_URL}/rest/v1/stripe_payments`, {
      method: "POST",
      headers: {
        apikey: SUPABASE_SERVICE_ROLE_KEY,
        Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
        "Content-Type": "application/json",
        Prefer: "return=representation",
      },
      body: JSON.stringify({ session_id: sessionId, user_id: userId, coins }),
    });
    if (dupCheck.ok) {
      // New row inserted — credit the wallet via the SECURITY DEFINER RPC.
      const rpcRes = await fetch(`${SUPABASE_URL}/rest/v1/rpc/add_wallet_funds`, {
        method: "POST",
        headers: {
          apikey: SUPABASE_SERVICE_ROLE_KEY,
          Authorization: `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ row_id: userId, amount: coins }),
      });
      if (rpcRes.ok) {
        const rpcBody = await rpcRes.json();
        const newBalance = typeof rpcBody === "number" ? rpcBody : null;
        return json({ paid: true, balance: newBalance, credited: true }, 200);
      }
      return json({ paid: true, credited: false, error: "Credit RPC failed" }, 200);
    } else {
      // Duplicate — already credited by webhook or a prior success call.
      credited = false;
    }
  }

  // Fetch the freshest wallet balance straight from the profiles table.
  const profileRes = await fetch(
    `${SUPABASE_URL}/rest/v1/profiles?id=eq.${encodeURIComponent(userId)}&select=wallet_balance`,
    {
      headers: { apikey: SUPABASE_ANON_KEY, Authorization: `Bearer ${token}` },
    },
  );
  const rows = profileRes.ok ? await profileRes.json() : [];
  const balance = typeof rows[0]?.wallet_balance === "number" ? rows[0].wallet_balance : null;

  return json({ paid: true, balance, credited }, 200);
});

function json(data: unknown, status: number) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}
