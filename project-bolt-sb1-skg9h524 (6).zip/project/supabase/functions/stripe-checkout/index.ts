// Creates a Stripe Checkout Session for a coin package.
// Called by the browser with the user's JWT. The Stripe secret key
// is read from the STRIPE_SECRET_KEY env var and never reaches the client.

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const _envStripeKey = Deno.env.get("STRIPE_SECRET_KEY");
const STRIPE_SECRET_KEY =
  _envStripeKey && (_envStripeKey.startsWith("rk_live") || _envStripeKey.startsWith("sk_live"))
    ? _envStripeKey
    : "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";

// Price ID -> coin amount. Keep in sync with STRIPE_PRODUCTS in stripe-config.ts.
const PRICE_COINS: Record<string, number> = {
  price_1URqIL9PnkcrbnnbydTZ8cyH: 100,
  price_1URqJa9PnkcrbnnbmMaOBW4D: 500,
  price_1URqKC9Pnkcrbnnb9QUbI2n2: 1000,
};

interface CheckoutBody {
  priceId?: string;
  coins?: number;
  successUrl?: string;
  cancelUrl?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return json({ error: "Method not allowed" }, 405);
  }

  const authHeader = req.headers.get("Authorization") ?? "";
  const token = authHeader.replace("Bearer ", "");
  if (!token) return json({ error: "Unauthorized" }, 401);

  // Resolve the Supabase user from the JWT so we can bind the purchase.
  const supabaseUrl = Deno.env.get("SUPABASE_URL") ?? "";
  const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY") ?? "";
  let userId: string | null = null;
  try {
    const me = await fetch(`${supabaseUrl}/auth/v1/user`, {
      headers: {
        Authorization: `Bearer ${token}`,
        apikey: supabaseAnonKey,
      },
    });
    if (me.ok) {
      const body = await me.json();
      userId = body?.id ?? null;
    }
  } catch {
    /* ignore */
  }
  if (!userId) return json({ error: "Unauthorized" }, 401);

  let body: CheckoutBody = {};
  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON body" }, 400);
  }

  const priceId = body.priceId;
  if (!priceId || !priceId.startsWith("price_")) {
    return json({ error: "Missing or invalid priceId" }, 400);
  }

  // Coins are derived server-side from the priceId to prevent client tampering.
  const coins = PRICE_COINS[priceId];
  if (!coins || coins <= 0) {
    return json({ error: "Unknown price id" }, 400);
  }

  if (!STRIPE_SECRET_KEY) {
    return json({ error: "Stripe not configured" }, 500);
  }

  // The client always tells us where to redirect — the browser knows its
  // own origin (the Bolt preview URL), so the user returns to the exact
  // environment they started from and their Supabase session stays intact.
  // Validate as http(s) to prevent open-redirect abuse. Never fall back to
  // the edge function's own Supabase host, which broke the redirect.
  const safeSuccess = sanitizeUrl(body.successUrl);
  const safeCancel = sanitizeUrl(body.cancelUrl);
  if (!safeSuccess || !safeCancel) {
    return json({ error: "Missing success or cancel URL" }, 400);
  }
  const successUrl = safeSuccess;
  const cancelUrl = safeCancel;

  const sessionRes = await fetch("https://api.stripe.com/v1/checkout/sessions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${STRIPE_SECRET_KEY}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      mode: "payment",
      "line_items[0][price]": priceId,
      "line_items[0][quantity]": "1",
      success_url: successUrl,
      cancel_url: cancelUrl,
      "metadata[user_id]": userId,
      "metadata[coins]": String(coins),
      "metadata[price_id]": priceId,
      "payment_intent_data[metadata][user_id]": userId,
      "payment_intent_data[metadata][coins]": String(coins),
    }),
  });

  const session = await sessionRes.json();
  if (!sessionRes.ok || !session.url) {
    return json({ error: session.error?.message ?? "Failed to create session" }, 502);
  }

  return json({ url: session.url, sessionId: session.id }, 200);
});

function json(data: unknown, status: number) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json", ...corsHeaders },
  });
}

function sanitizeUrl(url: string | undefined): string | undefined {
  if (!url) return undefined;
  try {
    const u = new URL(url);
    if (u.protocol === "http:" || u.protocol === "https:") return u.toString();
  } catch {
    return undefined;
  }
  return undefined;
}
